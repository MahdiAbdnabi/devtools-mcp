import { randomBytes as cryptoRandomBytes } from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import {
  DEFAULT_MAX_OUTPUT_CHARS,
  EXTRA_KEYS_CODE,
  EXTRA_KEYS_MESSAGE,
  SHORT_MAX,
  limitDiagnostics,
  measureOutputs,
  snapshotResult,
} from './limits.mjs';

const MIB = 1024 * 1024;
export const DEFAULT_READ_BYTES = 64 * MIB;
export const MAX_READ_BYTES = 256 * MIB;
/** `readChunks` holds one chunk at a time, so it may stream more than `readFile` can hold [DRIFT-100, ADR-045]. */
export const MAX_STREAM_BYTES = 512 * MIB;
export const DEFAULT_CHUNK_BYTES = MIB;
export const MAX_CHUNK_BYTES = 16 * MIB;
export const MAX_WRITE_BYTES = 64 * MIB;
export const MAX_RANDOM_BYTES = 1024;

/** A refused or failed file call; `code` becomes the diagnostic code. The message never holds a directory or an OS error text. */
export class FileAccessError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'FileAccessError';
    this.code = code;
  }
}

const CASE_INSENSITIVE = process.platform === 'win32';

/** On win32 only ASCII A-Z fold; every other code unit compares exactly, so the Kelvin sign is not a `k` (F-14). */
function normalise(filePath) {
  const resolved = path.resolve(filePath);
  return CASE_INSENSITIVE
    ? resolved.replace(/[A-Z]/g, (letter) => letter.toLowerCase())
    : resolved;
}

/** The last path segment, clipped; the only part of a path a diagnostic may show. */
function baseName(filePath) {
  const parts = String(filePath)
    .split(/[\\/]/)
    .filter((part) => part !== '');
  const name = parts.length > 0 ? parts[parts.length - 1] : '';
  return name.length > 80 ? `${name.slice(0, 80)}...` : name;
}

const sizeText = (bytes) =>
  bytes % MIB === 0 ? `${bytes / MIB} MiB` : `${bytes} bytes`;

const denied = (filePath) =>
  new FileAccessError(
    'E_FILE_DENIED',
    `access to "${typeof filePath === 'string' ? baseName(filePath) : ''}" is not allowed`,
  );
const tooLarge = (filePath, cap) =>
  new FileAccessError(
    'E_FILE_TOO_LARGE',
    `"${baseName(filePath)}" is larger than the limit of ${sizeText(cap)}`,
  );
const readFailed = (filePath) =>
  new FileAccessError('E_FILE_READ', `could not read "${baseName(filePath)}"`);
const writeFailed = (filePath) =>
  new FileAccessError(
    'E_FILE_WRITE',
    `could not write "${baseName(filePath)}"`,
  );

/** A requested limit is used only when it is a safe integer of at least `min`; it never exceeds `ceiling`. */
function limit(value, fallback, ceiling, min) {
  if (!Number.isSafeInteger(value) || value < min) return fallback;
  return Math.min(value, ceiling);
}

/** Opens a regular file; a directory, a pipe or a device is refused before it is opened. */
async function openRegular(filePath) {
  let info;
  try {
    info = await fs.stat(filePath);
  } catch {
    throw readFailed(filePath);
  }
  if (!info.isFile()) throw notRegular(filePath);
  let handle;
  try {
    handle = await fs.open(filePath, 'r');
  } catch {
    throw readFailed(filePath);
  }
  // The opened handle is checked too: the path may have been swapped for a pipe or device after the stat (F-17).
  try {
    if (!(await handle.stat()).isFile()) {
      await handle.close().catch(() => undefined);
      throw notRegular(filePath);
    }
  } catch (error) {
    await handle.close().catch(() => undefined);
    throw error instanceof FileAccessError ? error : readFailed(filePath);
  }
  return handle;
}

/** A buffer that owns its whole ArrayBuffer: no pool slice, no view into a larger buffer (F-15). */
function owned(buffer) {
  return buffer.byteOffset === 0 && buffer.buffer.byteLength === buffer.length
    ? buffer
    : new Uint8Array(buffer);
}

const notRegular = (filePath) =>
  new FileAccessError(
    'E_FILE_NOT_REGULAR',
    `"${baseName(filePath)}" is not a regular file`,
  );

const asIoError = (error, filePath) =>
  error instanceof FileAccessError ? error : readFailed(filePath);

/**
 * The rest of a file that grew after the stat. Reading goes on until the end, but the file is refused
 * once more than `cap` bytes exist, so growth that stays under the cap is not a false refusal.
 */
async function readGrowth(handle, head, cap, filePath) {
  const one = Buffer.alloc(1);
  const first = await handle.read(one, 0, 1, null);
  if (first.bytesRead === 0) return head;
  if (head.length + 1 > cap) throw tooLarge(filePath, cap);
  const parts = [head, one];
  let total = head.length + 1;
  const probe = Buffer.allocUnsafe(Math.min(MIB, cap + 1 - total));
  for (;;) {
    const room = Math.min(probe.length, cap + 1 - total);
    const { bytesRead } = await handle.read(probe, 0, room, null);
    if (bytesRead === 0) return Buffer.concat(parts, total);
    total += bytesRead;
    if (total > cap) throw tooLarge(filePath, cap);
    parts.push(Buffer.from(probe.subarray(0, bytesRead)));
  }
}

async function readWhole(filePath, cap) {
  const handle = await openRegular(filePath);
  try {
    const { size } = await handle.stat();
    // The size comes from the opened handle and is checked before any byte is read or allocated.
    if (size > cap) throw tooLarge(filePath, cap);
    const buffer = Buffer.allocUnsafe(size);
    let filled = 0;
    while (filled !== size) {
      const { bytesRead } = await handle.read(
        buffer,
        filled,
        size - filled,
        null,
      );
      // A file that shrank after the stat returns what is left.
      if (bytesRead === 0) return owned(buffer.subarray(0, filled));
      filled += bytesRead;
    }
    return owned(await readGrowth(handle, buffer, cap, filePath));
  } catch (error) {
    throw asIoError(error, filePath);
  } finally {
    await handle.close().catch(() => undefined);
  }
}

export function makeContext(
  grants,
  now,
  random = (length) => cryptoRandomBytes(length),
) {
  const readable = new Set(
    [...grants.read, ...(grants.legacy ?? [])].map(normalise),
  );
  const writable = new Set(grants.write.map(normalise));
  // Paths granted only through the 1.0 `allowedPaths` keep the 1.0 behaviour: a write replaces the file.
  const legacy = new Set((grants.legacy ?? []).map(normalise));
  const check = (set, filePath) => {
    if (typeof filePath !== 'string' || !set.has(normalise(filePath)))
      throw denied(filePath);
  };
  return {
    async readFile(filePath, options) {
      check(readable, filePath);
      const cap = limit(
        options?.maxBytes,
        DEFAULT_READ_BYTES,
        MAX_READ_BYTES,
        0,
      );
      return readWhole(filePath, cap);
    },
    async *readChunks(filePath, options) {
      check(readable, filePath);
      const cap = limit(
        options?.maxBytes,
        DEFAULT_READ_BYTES,
        MAX_STREAM_BYTES,
        0,
      );
      const chunkBytes = limit(
        options?.chunkBytes,
        DEFAULT_CHUNK_BYTES,
        MAX_CHUNK_BYTES,
        1,
      );
      const handle = await openRegular(filePath);
      try {
        const { size } = await handle.stat();
        if (size > cap) throw tooLarge(filePath, cap);
        const buffer = Buffer.allocUnsafe(chunkBytes);
        let total = 0;
        for (;;) {
          const { bytesRead } = await handle.read(buffer, 0, chunkBytes, null);
          if (bytesRead === 0) break;
          total += bytesRead;
          // A file that grows while it is read stops at the cap instead of running on.
          if (total > cap) throw tooLarge(filePath, cap);
          yield Uint8Array.from(buffer.subarray(0, bytesRead));
        }
      } catch (error) {
        throw asIoError(error, filePath);
      } finally {
        await handle.close().catch(() => undefined);
      }
    },
    async writeFile(filePath, data, options) {
      if (typeof filePath !== 'string') throw denied(filePath);
      const key = normalise(filePath);
      if (!writable.has(key) && !legacy.has(key)) throw denied(filePath);
      const replace =
        options?.overwrite ?? (legacy.has(key) && !writable.has(key));
      if (!(data instanceof Uint8Array))
        throw new TypeError('writeFile data must be a Uint8Array');
      if (data.byteLength > MAX_WRITE_BYTES)
        throw tooLarge(filePath, MAX_WRITE_BYTES);
      let handle;
      try {
        handle = await fs.open(filePath, replace === true ? 'w' : 'wx');
      } catch (error) {
        if (error.code === 'EEXIST') {
          throw new FileAccessError(
            'E_FILE_EXISTS',
            `"${baseName(filePath)}" already exists; allow overwrite to replace it`,
          );
        }
        throw writeFailed(filePath);
      }
      try {
        // The opened target must be a regular file (F-17).
        if (!(await handle.stat()).isFile()) throw notRegular(filePath);
        await handle.writeFile(data);
      } catch (error) {
        throw error instanceof FileAccessError ? error : writeFailed(filePath);
      } finally {
        await handle.close().catch(() => undefined);
      }
    },
    randomBytes(length) {
      if (
        !Number.isInteger(length) ||
        length < 1 ||
        length > MAX_RANDOM_BYTES
      ) {
        throw new RangeError(
          `randomBytes length must be an integer from 1 to ${MAX_RANDOM_BYTES}`,
        );
      }
      return Uint8Array.from(random(length));
    },
    now,
  };
}

const errorText = (error) => {
  try {
    return error instanceof Error ? error.message : String(error);
  } catch {
    return 'unprintable thrown value';
  }
};

const failure = (code, message) => ({
  outputs: [],
  diagnostics: [{ severity: 'error', code, message }],
});

/** A string default must match its own pattern; evaluated here so the host never runs a plugin regex. */
function checkDefaultPatterns(tool, index, problems) {
  if (!Array.isArray(tool.options)) return;
  tool.options.forEach((option, at) => {
    if (typeof option !== 'object' || option === null) return;
    if (typeof option.pattern !== 'string') return;
    if (typeof option.default !== 'string') return;
    let matches = true;
    try {
      matches = new RegExp(option.pattern).test(option.default);
    } catch {
      // an invalid pattern is reported by the host validator
    }
    if (!matches)
      problems.push(
        `tools[${index}].options[${at}].default must match pattern ${option.pattern}`,
      );
  });
}

/** Descriptors for the host (no functions) plus the reasons the module cannot be used. */
export function describePlugin(mod, withDocs = false) {
  const list = mod.tools;
  if (!Array.isArray(list))
    return { tools: [], problems: ['tools must be an array'] };
  const tools = [];
  const problems = [];
  list.forEach((tool, index) => {
    if (typeof tool !== 'object' || tool === null) {
      problems.push(`tools[${index}] must be an object`);
      return;
    }
    if (typeof tool.run !== 'function')
      problems.push(`tools[${index}].run must be a function`);
    checkDefaultPatterns(tool, index, problems);
    tools.push(
      Object.fromEntries(Object.entries(tool).filter(([key]) => key !== 'run')),
    );
  });
  // API 1.2 (ADR-166): the optional docs export travels with the tools, only for a plugin that declares 1.2
  // (an older plugin's export of that name means nothing, review F-01); one that cannot be copied is reported
  if (!withDocs || mod.docs === undefined) return { tools, problems };
  try {
    return { tools, problems, docs: structuredClone(mod.docs) };
  } catch {
    return {
      tools,
      problems,
      docsProblem:
        'the docs export cannot be copied out of the plugin (it holds a function or another value that is not data)',
    };
  }
}

/** The clock of a call: a function (in-process callers), a fixed `nowMs` from the host, or the wall clock. */
function clockOf(request) {
  if (typeof request.now === 'function') return request.now;
  if (typeof request.nowMs === 'number') {
    const fixed = request.nowMs;
    return () => fixed;
  }
  return Date.now;
}

export async function runToolFromModule(mod, request) {
  const tool = Array.isArray(mod.tools)
    ? mod.tools.find(
        (candidate) => candidate && candidate.id === request.toolId,
      )
    : undefined;
  if (tool === undefined) {
    return failure(
      'E_UNKNOWN_TOOL',
      `tool "${request.toolId}" is not exported by the plugin entry`,
    );
  }
  const mismatches = [];
  for (const check of request.patternChecks ?? []) {
    let matches = false;
    try {
      matches = new RegExp(check.pattern).test(check.value);
    } catch {
      // an invalid pattern never matches
    }
    if (!matches)
      mismatches.push({
        severity: 'error',
        code: 'E_OPTION_INVALID',
        message: `must match pattern ${check.pattern}`,
        path: `options.${check.id}`,
      });
  }
  if (mismatches.length > 0) return { outputs: [], diagnostics: mismatches };
  // `allowedPaths` is the 1.0 grant: each path may be read and written.
  const grants = {
    read: request.grants?.read ?? [],
    write: request.grants?.write ?? [],
    legacy: request.allowedPaths ?? [],
  };
  const ctx = makeContext(grants, clockOf(request), request.random);
  try {
    const result = await tool.run(request.inputs, request.options, ctx);
    // One snapshot: every field of the result is read once, a hole is refused before anything is walked, and
    // what is checked, capped and posted is the copy (review 1: F-01, F-02, F-05).
    const cap = request.maxOutputChars ?? DEFAULT_MAX_OUTPUT_CHARS;
    // The ids the tool declares: an id longer than the short-field cut is kept only when it is one of them (F-19).
    const outputs = Array.isArray(tool.outputs) ? tool.outputs : [];
    const declared = {
      count: outputs.length,
      ids: new Set(
        outputs
          .map((o) => o?.id)
          .filter((id) => typeof id === 'string' && id.length > SHORT_MAX),
      ),
    };
    const snap = snapshotResult(result, cap, declared);
    if (snap.oversize !== undefined) {
      return failure(
        'E_OUTPUT_TOO_LARGE',
        `the result has ${snap.oversize} characters, over the limit of ${cap}`,
      );
    }
    if (snap.refusal !== undefined) {
      return {
        outputs: [],
        diagnostics: [
          {
            severity: 'error',
            code: 'E_RESULT_INVALID',
            message: snap.refusal.message,
            path: snap.refusal.path,
          },
        ],
      };
    }
    if (snap.cyclic === true)
      return failure(
        'E_OUTPUT_TOO_LARGE',
        'the result holds a tree that contains itself, so it has no end',
      );
    const value = snap.value;
    // The note is an ordinary info entry, so the cap treats it like any other (a full list drops it and says so).
    let total = snap.total;
    if (snap.stripped === true && total !== undefined) total += 1;
    else if (snap.stripped === true && Array.isArray(value?.diagnostics))
      value.diagnostics[value.diagnostics.length] = {
        __proto__: null,
        severity: 'info',
        code: EXTRA_KEYS_CODE,
        message: EXTRA_KEYS_MESSAGE,
      };
    return applyLimits(value, cap, request.noticeMark, {
      total,
      errors: snap.errors,
    });
  } catch (error) {
    if (error instanceof FileAccessError)
      return failure(error.code, error.message);
    if (error instanceof RangeError && STRING_LENGTH.test(error.message))
      return failure(
        'E_OUTPUT_TOO_LARGE',
        'the result is too large to build as one text or list',
      );
    return failure('E_TOOL_THROW', errorText(error));
  }
}

/** The "string/array too long" RangeErrors of the engine; a stack overflow is a different RangeError and stays a throw. */
const STRING_LENGTH =
  /Invalid (string|array|typed array|array buffer) length|Array buffer allocation failed/;

/** Caps the diagnostics, then refuses a result whose outputs hold more than `maxOutputChars` characters. */
function applyLimits(result, maxOutputChars, noticeMark, kept = {}) {
  if (typeof result !== 'object' || result === null) return result;
  const diagnostics = limitDiagnostics(result.diagnostics, {
    mark: noticeMark,
    total: kept.total,
    errors: kept.errors,
  });
  // Measured again on the snapshot: the snapshot already charges a shared node at the depth where it is reached; this walk checks the same total on the copy.
  const size = measureOutputs(result.outputs, maxOutputChars);
  if (size > maxOutputChars) {
    return failure(
      'E_OUTPUT_TOO_LARGE',
      `the result has ${size} characters, over the limit of ${maxOutputChars}`,
    );
  }
  return diagnostics === result.diagnostics
    ? result
    : { ...result, diagnostics };
}
