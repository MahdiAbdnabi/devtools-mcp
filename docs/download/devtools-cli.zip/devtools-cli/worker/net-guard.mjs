import dgram from 'node:dgram';
import dns from 'node:dns';
import http from 'node:http';
import https from 'node:https';
import { syncBuiltinESMExports } from 'node:module';
import net from 'node:net';
import { fileURLToPath } from 'node:url';
import tls from 'node:tls';
import workerThreads from 'node:worker_threads';

// A tripwire for built-in code and honest plugins, not a sandbox: a plugin is trusted code and can put
// the originals back (RISK-001, ADR-118). Named-pipe connections stay allowed: the app itself uses them.

const CODE = 'E_NET_DENIED';
const WRAPPED = Symbol.for('devtools.netGuard.wrapped');
const active = new WeakMap();

const DNS_NAMES = [
  'lookup',
  'lookupService',
  'resolve',
  'resolve4',
  'resolve6',
  'resolveAny',
  'resolveCaa',
  'resolveCname',
  'resolveMx',
  'resolveNaptr',
  'resolveNs',
  'resolvePtr',
  'resolveSoa',
  'resolveSrv',
  'resolveTlsa',
  'resolveTxt',
  'reverse',
];

const hostOnly = (value) => {
  const text = String(value ?? '');
  try {
    return new URL(text).host || text;
  } catch {
    return text.split(/[/?#]/)[0];
  }
};

const isLoopback = (address) =>
  typeof address === 'string' &&
  (address === '::1' || address === 'localhost' || address.startsWith('127.'));

/** `host:port` of a connect call, or null for a named pipe or unix socket (and for a call Node itself rejects). */
function connectTarget(args) {
  let first = args[0];
  if (Array.isArray(first)) first = first[0];
  if (first === undefined || first === null) return null;
  if (typeof first === 'object') {
    if (first.path) return null;
    return `${first.host ?? 'localhost'}:${first.port ?? ''}`;
  }
  if (typeof first === 'string' && Number.isNaN(Number(first))) return null;
  return `${typeof args[1] === 'string' ? args[1] : 'localhost'}:${String(first)}`;
}

function httpTarget(args) {
  const first = args[0];
  if (typeof first === 'string') return hostOnly(first);
  if (first !== null && typeof first === 'object') {
    if (typeof first.href === 'string') return hostOnly(first.href);
    return `${first.hostname ?? first.host ?? 'localhost'}:${first.port ?? ''}`;
  }
  return '';
}

/**
 * The address a datagram call aims at, or undefined when the call names none (a connected socket, or the
 * default loopback). `send` has two shapes, (msg, port, address, cb) and (msg, offset, length, port, address,
 * cb), and Node accepts a port as a numeric string: the address is the first argument after the message that
 * is a string and not a number.
 */
function udpAddress(method, args) {
  if (method === 'send')
    return args
      .slice(1)
      .find((v) => typeof v === 'string' && Number.isNaN(Number(v)));
  // bind(port, address, cb), bind({ port, address }), connect(port, address, cb)
  const first = args[0];
  if (first !== null && typeof first === 'object') return first.address;
  return typeof args[1] === 'string' ? args[1] : undefined;
}

function noop() {}

function defaultModules() {
  return { net, tls, dns, http, https, dgram, worker_threads: workerThreads };
}

/**
 * Installs the guard on `modules` (the real network modules unless injected) and on `globalObject.fetch`.
 * `modules.net` is required: it identifies the installation. Installing twice returns the first handle;
 * `uninstall` puts every original function back. With `nestedWorkers`, a `worker_threads.Worker` started afterwards
 * (fresh modules, so unguarded) is given `--import net-guard-preload.mjs`, which installs the guard in that
 * thread too. Only the plugin worker asks for this: the preload file sits next to this one only there.
 * Child processes, `process.binding` and listening sockets stay uncovered (docs/PLUGINS.md says so).
 */
export function installNetGuard({
  modules,
  globalObject,
  onDeny = noop,
  nestedWorkers = false,
} = {}) {
  const mods = modules ?? defaultModules();
  const target = globalObject ?? globalThis;
  const existing = active.get(mods.net);
  if (existing !== undefined) return existing;

  const restores = [];
  const report = (kind, where) => {
    try {
      onDeny({ kind, target: where });
    } catch {
      // a broken audit sink must not turn a denial into success
    }
  };
  const refuse = (kind, where) => {
    report(kind, where);
    return Object.assign(
      new Error(
        `${CODE}: network access is denied (${kind} to ${where || 'unknown target'})`,
      ),
      { code: CODE },
    );
  };
  const patch = (owner, name, make) => {
    const original = owner?.[name];
    if (typeof original !== 'function' || original[WRAPPED] === true) return;
    const wrapper = make(original);
    Object.defineProperty(wrapper, WRAPPED, { value: true });
    owner[name] = wrapper;
    restores.push(() => {
      owner[name] = original;
    });
  };

  const guardConnect = (kind) => (original) =>
    function guarded(...args) {
      const where = connectTarget(args);
      if (where !== null) throw refuse(kind, where);
      return Reflect.apply(original, this, args);
    };
  patch(mods.net.Socket?.prototype, 'connect', guardConnect('tcp'));
  patch(mods.net, 'connect', guardConnect('tcp'));
  patch(mods.net, 'createConnection', guardConnect('tcp'));
  patch(mods.tls, 'connect', guardConnect('tls'));

  const guardDns = (promise) => () =>
    function guarded(...args) {
      const error = refuse('dns', String(args[0] ?? ''));
      if (promise) return Promise.reject(error);
      const callback = args.find((a) => typeof a === 'function');
      if (callback === undefined) throw error;
      process.nextTick(callback, error);
      return undefined;
    };
  for (const name of DNS_NAMES) {
    patch(mods.dns, name, guardDns(false));
    patch(mods.dns?.promises, name, guardDns(true));
    patch(mods.dns?.Resolver?.prototype, name, guardDns(false));
    patch(mods.dns?.promises?.Resolver?.prototype, name, guardDns(true));
  }

  for (const [kind, mod] of [
    ['http', mods.http],
    ['https', mods.https],
  ]) {
    for (const name of ['request', 'get'])
      patch(
        mod,
        name,
        () =>
          function guarded(...args) {
            throw refuse(kind, httpTarget(args));
          },
      );
  }

  for (const method of ['send', 'bind', 'connect']) {
    patch(
      mods.dgram?.Socket?.prototype,
      method,
      (original) =>
        function guarded(...args) {
          const address = udpAddress(method, args);
          const open = method === 'bind' ? address === undefined : false;
          if (open || (address !== undefined && !isLoopback(address)))
            throw refuse('udp', address ?? 'any interface');
          return Reflect.apply(original, this, args);
        },
    );
  }

  if (nestedWorkers) {
    const preload = new URL('./net-guard-preload.mjs', import.meta.url);
    // `--import` guards a worker file and an ES module source; a CommonJS `eval` source also loads the preload by its first line (AC-14)
    patch(
      mods.worker_threads,
      'Worker',
      (Original) =>
        class GuardedWorker extends Original {
          constructor(file, given) {
            // One copy: the guard decides on the values that Node then gets, whatever a getter would answer next time.
            const options = { ...given };
            const argv = options.execArgv ?? process.execArgv;
            // The switch and its value must be adjacent: the href as the value of another switch does not load the preload.
            const imported = argv.some(
              (arg, i) => arg === '--import' && argv[i + 1] === preload.href,
            );
            // First, so a plugin's own --import cannot run before the guard and keep the original modules.
            const execArgv = imported
              ? argv
              : ['--import', preload.href, ...argv];
            if (options.eval && typeof file === 'string') {
              // Any truthy `eval` is a source string. A CommonJS source loads the preload by its first line; an ES module
              // source has no `require` there (the line does nothing) and is guarded by the `--import` above.
              const first = `typeof require === 'function' && require(${JSON.stringify(fileURLToPath(preload))});\n`;
              super(first + file, { ...options, execArgv });
              return;
            }
            super(file, { ...options, execArgv });
          }
        },
    );
  }

  patch(
    target,
    'fetch',
    () =>
      function guarded(input) {
        const where =
          typeof input === 'object' && input !== null && 'url' in input
            ? input.url
            : input;
        return Promise.reject(refuse('fetch', hostOnly(where)));
      },
  );

  // every (owner, name) pair is wrapped at most once, so the order of the restores does not matter
  const handle = {
    uninstall() {
      if (active.get(mods.net) !== handle) return;
      for (const restore of restores) restore();
      active.delete(mods.net);
      syncBuiltinESMExports();
    },
  };
  active.set(mods.net, handle);
  syncBuiltinESMExports();
  return handle;
}
