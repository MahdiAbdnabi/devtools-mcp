import { installNetGuard } from './net-guard.mjs';

// Loaded with --import into a worker thread that plugin code started: that thread has its own unguarded
// modules, so the guard is installed first (and again for any thread it starts in turn).
installNetGuard({ nestedWorkers: true });
