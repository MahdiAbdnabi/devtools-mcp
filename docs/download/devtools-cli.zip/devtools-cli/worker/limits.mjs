const MI = 1024 * 1024;
/** Characters a tool result may hold, counted over all outputs of every kind (RISK-006, RISK-007). */
export const DEFAULT_MAX_OUTPUT_CHARS = 128 * MI;
export const MAX_MAX_OUTPUT_CHARS = 512 * MI;
/** Diagnostics a result may carry; the rest is replaced by one info. */
export const MAX_DIAGNOSTICS = 1000;
/** The problems a result may list, and the outputs it may carry beyond the declared ones: the host's cap plus one [review 4, F-25]. */
export const MAX_PROBLEMS = MAX_DIAGNOSTICS + 1;
/** Characters of a diagnostic message or path. */
export const MAX_DIAGNOSTIC_TEXT = 2000;

/** Characters of a diagnostic code [GAP-654]. */
export const MAX_CODE_TEXT = 64;

// Captured when this module loads. The worker imports it before any plugin code runs, so the checks below never
// call a built-in that a plugin has replaced (review 1, F-01 and F-03).
const ObjectKeys = Object.keys;
const ObjectHasOwn = Object.hasOwn;
const ObjectSetPrototypeOf = Object.setPrototypeOf;
const ObjectDefineProperty = Object.defineProperty;
const ArrayIsArray = Array.isArray;
const NumberIsInteger = Number.isInteger;

const len = (value) => (typeof value === 'string' ? value.length : 0);

function treeSize(root, cap, start) {
  let total = start;
  const stack = [[root, 0]];
  while (stack.length > 0) {
    const [node, depth] = stack.pop();
    if (typeof node !== 'object' || node === null) continue;
    // label, value, two characters of indentation per level and one separator
    total += len(node.label) + len(node.value) + 2 * depth + 1;
    if (total > cap) return total;
    const children = node.children;
    if (ArrayIsArray(children))
      for (let i = 0; i < children.length; i++)
        stack.push([children[i], depth + 1]);
  }
  return total;
}

function tableSize(output, cap, start) {
  let total = start;
  const columns = output.columns;
  if (ArrayIsArray(columns))
    for (let i = 0; i < columns.length; i++) total += len(columns[i]) + 1;
  if (total > cap || !ArrayIsArray(output.rows)) return total;
  const rows = output.rows;
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    if (ArrayIsArray(row))
      for (let c = 0; c < row.length; c++) total += len(row[c]) + 1;
    if (total > cap) return total;
  }
  return total;
}

/**
 * Characters in the outputs of a result: text length; table cells plus one each (columns included); tree
 * labels, values, two per depth level and one per node; both sides of a diff. Counting stops once the
 * count passes `cap`, so a huge table behind a result is not walked to the end.
 */
export function measureOutputs(outputs, cap = Infinity) {
  if (!ArrayIsArray(outputs)) return 0;
  let total = 0;
  for (let i = 0; i < outputs.length; i++) {
    const output = outputs[i];
    if (typeof output !== 'object' || output === null) continue;
    if (output.kind === 'text') total += len(output.text);
    else if (output.kind === 'diff')
      total += len(output.left) + len(output.right);
    else if (output.kind === 'table') total = tableSize(output, cap, total);
    else if (output.kind === 'tree') total = treeSize(output.root, cap, total);
    if (total > cap) return total;
  }
  return total;
}

/** At most `max` UTF-16 units including the ellipsis; a surrogate pair is never split. */
export function clipText(text, max) {
  if (text.length <= max) return text;
  if (max < 1) return '';
  let end = max - 1;
  const high = text.charCodeAt(end - 1);
  const low = text.charCodeAt(end);
  if (high >= 0xd800 && high <= 0xdbff && low >= 0xdc00 && low <= 0xdfff) end--;
  return `${text.slice(0, end)}…`;
}

function cutField(diagnostic, key, max = MAX_DIAGNOSTIC_TEXT) {
  const value = diagnostic[key];
  return typeof value === 'string' && value.length > max
    ? clipText(value, max)
    : value;
}

/** The code of the notice that stands for diagnostics the host dropped. */
export const DROPPED_CODE = 'I_HOST_DIAGNOSTICS_DROPPED';
const DROPPED_TEXT =
  /^(at least )?(\d+) more diagnostics were dropped(?: \(limit \d+(?:, (\d+) errors?)?\))?/;

/**
 * What a drop notice says: how many entries were dropped, how many of them were errors (absent in a notice
 * that does not state it), and whether both numbers are a lower bound. Undefined for any other entry.
 */
export function droppedNoticeOf(diagnostic) {
  if (typeof diagnostic !== 'object' || diagnostic === null) return undefined;
  if (
    diagnostic.code !== DROPPED_CODE ||
    diagnostic.severity !== 'info' ||
    typeof diagnostic.message !== 'string'
  )
    return undefined;
  const found = DROPPED_TEXT.exec(diagnostic.message);
  if (found === null) return undefined;
  const count = Number(found[2]);
  const errors = found[3] === undefined ? undefined : Number(found[3]);
  if (!Number.isSafeInteger(count)) return undefined;
  if (errors !== undefined && !Number.isSafeInteger(errors)) return undefined;
  return { count, errors, atLeast: found[1] !== undefined };
}

/** How many diagnostics a host drop notice stands for; 0 for any other entry. */
export function droppedCountOf(diagnostic) {
  return droppedNoticeOf(diagnostic)?.count ?? 0;
}

const isError = (d) =>
  typeof d === 'object' && d !== null && d.severity === 'error';

/** The first MAX_DIAGNOSTICS entries, except that errors come first: the cap never hides one (F-18). Order is kept. */
function keepErrorsFirst(diagnostics) {
  let errors = 0;
  for (let i = 0; i < diagnostics.length; i++)
    if (isError(diagnostics[i])) errors++;
  const errorSlots = Math.min(errors, MAX_DIAGNOSTICS);
  const otherSlots = MAX_DIAGNOSTICS - errorSlots;
  let keptErrors = 0;
  let keptOthers = 0;
  const kept = [];
  for (let i = 0; i < diagnostics.length; i++) {
    const d = diagnostics[i];
    if (isError(d)) {
      if (keptErrors < errorSlots) {
        keptErrors++;
        kept[kept.length] = d;
      }
    } else if (keptOthers < otherSlots) {
      keptOthers++;
      kept[kept.length] = d;
    }
  }
  return kept;
}

/**
 * At most 1000 diagnostics (one info for the rest) with message and path cut at 2000 characters. The notice
 * states how many entries and how many errors were dropped. `atLeast` is for a list that was itself cut
 * short before it got here (the host's walk of an invalid result): the numbers are then a lower bound.
 * `mark` is put in the notice's `path`: the worker passes the call's nonce, which the plugin never sees, so
 * the host can tell the worker's notice from a forged one [GAP-560]. The notice is one literal with no
 * prototype, added with a captured defineProperty: no setter and no replaced method can be called with the
 * nonce in hand, and the loops use no method of the list (review 1, F-03).
 */
export function limitDiagnostics(diagnostics, options) {
  if (!ArrayIsArray(diagnostics)) return diagnostics;
  const total =
    typeof options?.total === 'number' ? options.total : diagnostics.length;
  const over = total > MAX_DIAGNOSTICS;
  const kept =
    diagnostics.length > MAX_DIAGNOSTICS
      ? keepErrorsFirst(diagnostics)
      : diagnostics;
  const marked = typeof options?.mark === 'string';
  const cut = marked ? ObjectSetPrototypeOf([], null) : [];
  let changed = over;
  for (let i = 0; i < kept.length; i++) {
    const d = kept[i];
    if (typeof d !== 'object' || d === null) {
      cut[i] = d;
      continue;
    }
    const message = cutField(d, 'message');
    const path = cutField(d, 'path');
    const code = cutField(d, 'code', MAX_CODE_TEXT);
    if (message === d.message && path === d.path && code === d.code) {
      cut[i] = d;
      continue;
    }
    changed = true;
    const copy = { ...d, message };
    if (d.path !== undefined) copy.path = path;
    if (d.code !== undefined) copy.code = code;
    cut[i] = copy;
  }
  if (!changed) return diagnostics;
  if (over) {
    let errors = options?.errors;
    if (typeof errors !== 'number') {
      errors = 0;
      for (let i = 0; i < diagnostics.length; i++)
        if (isError(diagnostics[i])) errors++;
    }
    const droppedErrors = Math.max(0, errors - MAX_DIAGNOSTICS);
    const message = `${options?.atLeast === true ? 'at least ' : ''}${total - MAX_DIAGNOSTICS} more diagnostics were dropped (limit ${MAX_DIAGNOSTICS}, ${droppedErrors} ${droppedErrors === 1 ? 'error' : 'errors'})`;
    const notice = marked
      ? {
          __proto__: null,
          severity: 'info',
          code: DROPPED_CODE,
          message,
          path: options.mark,
        }
      : { severity: 'info', code: DROPPED_CODE, message };
    ObjectDefineProperty(cut, cut.length, {
      value: notice,
      writable: true,
      enumerable: true,
      configurable: true,
    });
  }
  return cut;
}

/** The note that says keys outside the result contract were removed; one per result [GAP-654]. */
export const EXTRA_KEYS_CODE = 'I_RESULT_EXTRA_KEYS';
export const EXTRA_KEYS_MESSAGE =
  'fields outside the result contract were dropped';

// What the contract allows in each field: a short string (kind, language, severity: cut at 256 characters; an id: kept if declared), a long string
// (counted), a string the diagnostics cap cuts later, an integer, or a list or record the snapshot copies itself.
const spec = (kinds) => {
  const names = ObjectKeys(kinds);
  const has = { __proto__: null };
  for (let i = 0; i < names.length; i++) has[names[i]] = true;
  return { names, has, kinds };
};
const RESULT_SPEC = spec({ outputs: 'list', diagnostics: 'list' });
const DIAGNOSTIC_SPEC = spec({
  severity: 'short',
  message: 'free',
  line: 'int',
  column: 'int',
  path: 'free',
  code: 'free',
});
const BASIC_OUTPUT = { id: 'short', kind: 'short', language: 'short' };
const BASIC_SPEC = spec(BASIC_OUTPUT);
// A lookup without a prototype: a kind named `constructor` finds nothing (review 1, F-07).
const OUTPUT_SPECS = {
  __proto__: null,
  text: spec({ ...BASIC_OUTPUT, text: 'text' }),
  diff: spec({ ...BASIC_OUTPUT, left: 'text', right: 'text' }),
  table: spec({ ...BASIC_OUTPUT, columns: 'list', rows: 'list' }),
  tree: spec({ ...BASIC_OUTPUT, root: 'list' }),
};
const NODE_SPEC = spec({ label: 'text', value: 'text', children: 'list' });
const outputSpec = (kind) =>
  (typeof kind === 'string' ? OUTPUT_SPECS[kind] : undefined) ?? BASIC_SPEC;

/** Longest kind, language or severity the snapshot keeps; a longer one is cut (invalid either way). An output id longer than this is kept when the tool declares it and refused by name otherwise. */
export const SHORT_MAX = 256;
/** Lists longer than this are not searched for keys that are not indexes (that needs one string per item). */
const SMALL_LIST = 4096;
const INDEX_KEY = /^(?:0|[1-9]\d*)$/;

/** True when a list of at most SMALL_LIST items has an own key that is not an index (`index`, `input`, `groups`, a plugin's own). */
function hasNamedKeys(list) {
  const n = list.length;
  return n <= SMALL_LIST && ObjectKeys(list).length > n;
}

// ---- the snapshot the worker posts: a contract-only copy, every field read once ----

/** Why the snapshot stopped. `leaf` still needs the path of its parent; `done` has its final path and message. */
class Refusal {
  constructor(path, message, kind) {
    this.path = path;
    this.message = message;
    this.kind = kind;
  }
}
const subjectOf = (path) => path.slice(path.lastIndexOf('.') + 1);
// A top-level item (`diagnostics[3]`) is named by what it is, as the host names it; the path is printed once, by the caller.
const ITEM = /^(outputs|diagnostics)\[\d+\]$/;
const done = (path, text) => {
  const item = ITEM.exec(path);
  const subject =
    item === null
      ? subjectOf(path)
      : item[1] === 'outputs'
        ? 'output'
        : 'diagnostic';
  return new Refusal(path, `${subject} ${text}`, 'done');
};
const sparse = (path) => done(path, 'is a sparse array (it has holes)');
const withPath = (error, prefix) => {
  if (!(error instanceof Refusal)) return error;
  if (error.kind !== 'leaf' && error.kind !== 'leafraw') return error;
  const text =
    error.kind === 'leaf' ? `${error.path} ${error.message}` : error.message;
  return new Refusal(`${prefix}.${error.path}`, text, 'done');
};
const SetHas = Set.prototype.has;
const SetAdd = Set.prototype.add;
const SetDelete = Set.prototype.delete;
const MapGet = Map.prototype.get;
const MapSet = Map.prototype.set;
const HOLE = { hole: true };
const BAD = { bad: true };
const newList = () => ObjectSetPrototypeOf([], null);

/**
 * The last REUSE_WINDOW distinct sources of a list (rows, tree leaves, outputs) with the copy and the size of
 * each, in a ring. A source found in it is not copied again: its copy is reused and its size charged again, so
 * `fill()`, two shared constants in any order and a few interned values cost one copy each, as the structured
 * clone cost them. More than REUSE_WINDOW distinct shared objects in rotation are copied once per reference
 * (the timeout and the worker heap contain that) [DC-078 A, GAP-855].
 */
const REUSE_WINDOW = 8;
function newWindow() {
  return { src: [], copy: [], size: [], next: 0 };
}
function windowFind(window, source) {
  for (let k = 0; k < window.src.length; k++)
    if (window.src[k] === source) return k;
  return -1;
}
function windowAdd(window, source, copy, size) {
  const k = window.next;
  window.src[k] = source;
  window.copy[k] = copy;
  window.size[k] = size;
  window.next = (k + 1) % REUSE_WINDOW;
}

/** Counts characters as they are copied; the copy ends the moment the cap is passed, so it is bounded by the cap [review 2, F-15]. */
function charge(st, n) {
  st.chars += n;
  if (st.chars > st.cap) throw new Refusal('', '', 'oversize');
}

/** Copies a list of strings (columns, the cells of a row) by index; HOLE at the first hole, BAD (`st.badIndex`) at a cell that is not a string. */
function copyFlat(src, st) {
  const n = src.length;
  if (hasNamedKeys(src)) st.stripped = true;
  const out = newList();
  for (let i = 0; i < n; i++) {
    if (!ObjectHasOwn(src, i)) return HOLE;
    const cell = src[i];
    if (typeof cell !== 'string') {
      st.badIndex = i;
      return BAD;
    }
    charge(st, cell.length + 1);
    out[i] = cell;
  }
  return out;
}

/** The value of a leaf field if it has the type the contract names; a refusal (path: the field) if not. */
function leaf(name, kind, value, st) {
  if (kind === 'list') return value;
  if (kind === 'int') {
    if (typeof value !== 'number' || !NumberIsInteger(value))
      throw new Refusal(name, 'must be an integer', 'leaf');
    return value;
  }
  if (typeof value !== 'string')
    throw new Refusal(name, 'must be a string', 'leaf');
  if (kind === 'free') return value;
  // An output id has no length limit in the contract: one that the tool declares is kept whole. An undeclared one is
  // refused by its own name (cut, two of them could look like one output returned twice) [review 3, F-19].
  if (name === 'id' && value.length > SHORT_MAX) {
    if (st.ids !== undefined && SetHas.call(st.ids, value)) return value;
    throw new Refusal(
      'id',
      `output "${value.slice(0, 80)}" is not declared by the tool`,
      'leafraw',
    );
  }
  const kept =
    kind === 'short' && value.length > SHORT_MAX
      ? value.slice(0, SHORT_MAX)
      : value;
  // A short field is not charged: the cap keeps its meaning of text, cells, labels and values. Each is cut at 256
  // characters, and the number of outputs and kept diagnostics is bounded before they are copied.
  if (kind === 'text') charge(st, kept.length);
  return kept;
}

/** A record of the named fields only, each read once and checked for its type; `kind` may be given when it was read already. */
function copyRecord(src, fields, st, kind) {
  const names = ObjectKeys(src);
  for (let i = 0; i < names.length; i++)
    if (fields.has[names[i]] !== true) st.stripped = true;
  const out = { __proto__: null };
  for (let i = 0; i < fields.names.length; i++) {
    const name = fields.names[i];
    const value = name === 'kind' && kind !== undefined ? kind : src[name];
    if (value !== undefined)
      out[name] = leaf(name, fields.kinds[name], value, st);
  }
  return out;
}

const isObject = (v) => typeof v === 'object' && v !== null && !ArrayIsArray(v);

/** One node without its children: label and value are counted, and so is the node (two characters per level and one), as `treeSize` does. */
function nodeRecord(src, st, depth) {
  const before = st.chars;
  const rec = copyRecord(src, NODE_SPEC, st);
  charge(st, 2 * depth + 1);
  const kids = rec.children;
  const self = st.chars - before;
  if (kids === undefined) return { rec, kids: undefined, self };
  if (!ArrayIsArray(kids))
    throw new Refusal('children', 'must be an array', 'leaf');
  delete rec.children;
  return { rec, kids, self };
}

/** The path of child `i` of `frame`, built only when a refusal needs it. */
const hereOf = (at, frame, i) => `${framePath(at, frame)}.children[${i}]`;

/** The path of the node of `frame`, below `at` (the root's path). */
function framePath(at, frame) {
  let path = '';
  for (let f = frame; f.parent !== null; f = f.parent)
    path = `.children[${f.index}]${path}`;
  return at + path;
}

/**
 * Copies a tree node by node, iteratively. The size is charged as nodes are copied, so the copy stops at the
 * cap. A node reached again by another path (a shared node, not a cycle) is copied once: the copy is reused
 * and its whole size is charged again at the depth it is reached now (the same count `measureOutputs` makes), so a tree of a few dozen objects that expands to millions of nodes is
 * refused after a few dozen steps. A node that lists one of its own ancestors is a cycle, which has no end.
 */
function copyTree(root, at, st) {
  if (!isObject(root)) throw done(at, 'must be an object');
  let first;
  try {
    first = nodeRecord(root, st, 0);
  } catch (error) {
    throw withPath(error, at);
  }
  if (first.kids === undefined) return first.rec;
  const onPath = new Set();
  const finished = new Map();
  const leaves = newWindow();
  // Depth first, one child at a time: a node is finished (and can be reused) before its next sibling is looked at.
  const stack = [
    {
      src: root,
      rec: first.rec,
      kids: first.kids,
      parent: null,
      index: -1,
      depth: 0,
      total: first.self,
      nodes: 1,
      next: -1,
      list: undefined,
    },
  ];
  while (stack.length > 0) {
    const frame = stack[stack.length - 1];
    const kids = frame.kids;
    if (frame.next === -1) {
      SetAdd.call(onPath, frame.src);
      if (hasNamedKeys(kids)) st.stripped = true;
      frame.list = newList();
      frame.rec.children = frame.list;
      frame.next = 0;
    }
    if (frame.next >= kids.length) {
      stack.pop();
      SetDelete.call(onPath, frame.src);
      MapSet.call(finished, frame.src, {
        rec: frame.rec,
        size: frame.total,
        nodes: frame.nodes,
        depth: frame.depth,
      });
      if (frame.parent !== null) {
        frame.parent.total += frame.total;
        frame.parent.nodes += frame.nodes;
      }
      continue;
    }
    const i = frame.next++;
    if (!ObjectHasOwn(kids, i))
      throw sparse(`${framePath(at, frame)}.children`);
    const child = kids[i];
    if (!isObject(child)) throw done(hereOf(at, frame, i), 'must be an object');
    if (SetHas.call(onPath, child)) throw new Refusal(at, '', 'cyclic');
    const seen = MapGet.call(finished, child);
    if (seen !== undefined) {
      // Charged at the depth it is reached now: a subtree of `nodes` nodes costs 2 characters more for each level it sits lower.
      const cost = seen.size + 2 * seen.nodes * (frame.depth + 1 - seen.depth);
      charge(st, cost);
      frame.total += cost;
      frame.nodes += seen.nodes;
      frame.list[i] = seen.rec;
      continue;
    }
    // A leaf seen among the last few (`new Array(n).fill(leaf)`, two shared leaves in any order): one copy, charged every time.
    const seenLeaf = windowFind(leaves, child);
    if (seenLeaf >= 0) {
      // The window keeps the leaf's size without the depth term; the term is added for the depth it is reached at now.
      const cost = leaves.size[seenLeaf] + 2 * (frame.depth + 1) + 1;
      charge(st, cost);
      frame.total += cost;
      frame.nodes += 1;
      frame.list[i] = leaves.copy[seenLeaf];
      continue;
    }
    let sub;
    try {
      sub = nodeRecord(child, st, frame.depth + 1);
    } catch (error) {
      throw withPath(error, hereOf(at, frame, i));
    }
    frame.list[i] = sub.rec;
    if (sub.kids === undefined) {
      frame.total += sub.self;
      frame.nodes += 1;
      windowAdd(leaves, child, sub.rec, sub.self - (2 * (frame.depth + 1) + 1));
    } else
      stack.push({
        src: child,
        rec: sub.rec,
        kids: sub.kids,
        parent: frame,
        index: i,
        depth: frame.depth + 1,
        total: sub.self,
        nodes: 1,
        next: -1,
        list: undefined,
      });
  }
  return first.rec;
}

function copyRows(rows, at, st) {
  if (hasNamedKeys(rows)) st.stripped = true;
  const list = newList();
  const window = newWindow();
  for (let r = 0; r < rows.length; r++) {
    if (!ObjectHasOwn(rows, r)) throw sparse(`${at}.rows`);
    const row = rows[r];
    if (!ArrayIsArray(row))
      throw done(`${at}.rows[${r}]`, 'must be an array of strings');
    const seen = windowFind(window, row);
    if (seen >= 0) {
      charge(st, window.size[seen]);
      list[r] = window.copy[seen];
      continue;
    }
    const before = st.chars;
    const cells = copyFlat(row, st);
    if (cells === HOLE) throw sparse(`${at}.rows[${r}]`);
    if (cells === BAD)
      throw done(`${at}.rows[${r}][${st.badIndex}]`, 'must be a string');
    list[r] = cells;
    windowAdd(window, row, cells, st.chars - before);
  }
  return list;
}

function copyOutput(output, at, st) {
  if (!isObject(output)) throw done(at, 'must be an object');
  const kind = output.kind;
  const fields = outputSpec(kind);
  let out;
  try {
    out = copyRecord(output, fields, st, kind);
  } catch (error) {
    throw withPath(error, at);
  }
  if (fields === OUTPUT_SPECS.table) {
    if (out.columns !== undefined) {
      if (!ArrayIsArray(out.columns))
        throw done(`${at}.columns`, 'must be an array of strings');
      const columns = copyFlat(out.columns, st);
      if (columns === HOLE) throw sparse(`${at}.columns`);
      if (columns === BAD)
        throw done(`${at}.columns[${st.badIndex}]`, 'must be a string');
      out.columns = columns;
    }
    if (out.rows !== undefined) {
      if (!ArrayIsArray(out.rows)) throw done(`${at}.rows`, 'must be an array');
      out.rows = copyRows(out.rows, at, st);
    }
  } else if (fields === OUTPUT_SPECS.tree && out.root !== undefined) {
    out.root = copyTree(out.root, `${at}.root`, st);
  }
  return out;
}

function copyDiagnostic(d, at, st) {
  if (!isObject(d)) throw done(at, 'must be an object');
  try {
    return copyRecord(d, DIAGNOSTIC_SPEC, st);
  } catch (error) {
    throw withPath(error, at);
  }
}

function copyList(src, key, copyItem, st) {
  if (hasNamedKeys(src)) st.stripped = true;
  const list = newList();
  const window = newWindow();
  for (let i = 0; i < src.length; i++) {
    if (!ObjectHasOwn(src, i)) throw sparse(key);
    const item = src[i];
    const seen = windowFind(window, item);
    if (seen >= 0) {
      charge(st, window.size[seen]);
      list[i] = window.copy[seen];
      continue;
    }
    const before = st.chars;
    list[i] = copyItem(item, `${key}[${i}]`, st);
    windowAdd(window, item, list[i], st.chars - before);
  }
  return list;
}

/**
 * The one copy of a tool's result that the worker checks, caps and posts [GAP-654, GAP-711, review 1 and 2].
 * Every field the contract names is read exactly once, with built-ins captured at load, into lists and
 * records that have no prototype. A leaf must have the type the contract names (a string, an integer), so no
 * array or object can ride in a cell, a label or a severity; fields outside the contract (keys of an object,
 * named keys of an array) are not copied, and `stripped` says whether any existed (not looked for on a list
 * longer than 4096 items). The size is charged while copying and the copy ends at `cap` (`oversize`).
 * Results: `{ value, stripped }`, `{ refusal: { path, message } }`, `{ oversize }` or `{ cyclic }`.
 * Plugins are trusted code (DC-072 A): the snapshot guards against honest bugs and honest data shapes.
 */
export function snapshotResult(result, cap = Infinity, declared) {
  if (typeof result !== 'object' || result === null)
    return { value: result, stripped: false };
  if (ArrayIsArray(result)) return { value: newList(), stripped: false };
  const st = {
    stripped: false,
    chars: 0,
    cap,
    badIndex: -1,
    ids: declared?.ids,
  };
  const declaredCount = declared?.count ?? 0;
  let total;
  let errors;
  try {
    const names = ObjectKeys(result);
    for (let i = 0; i < names.length; i++)
      if (RESULT_SPEC.has[names[i]] !== true) st.stripped = true;
    const outputs = result.outputs;
    const diagnostics = result.diagnostics;
    const value = { __proto__: null };
    if (outputs !== undefined) {
      if (!ArrayIsArray(outputs)) throw done('outputs', 'must be an array');
      // Every output is declared and returned once, so no valid result is longer; the host refuses a list longer by more
      // than 1001 without reading it, and so does the snapshot, before it copies one (review 3, F-20).
      if (outputs.length > declaredCount + MAX_PROBLEMS)
        throw new Refusal(
          'outputs',
          `the result has ${outputs.length} outputs, the tool declares only ${declaredCount}`,
          'done',
        );
      value.outputs = copyList(outputs, 'outputs', copyOutput, st);
    }
    if (diagnostics !== undefined) {
      if (!ArrayIsArray(diagnostics))
        throw done('diagnostics', 'must be an array');
      let source = diagnostics;
      if (diagnostics.length > MAX_DIAGNOSTICS) {
        // Only the entries that are kept are copied (errors first, as `limitDiagnostics` keeps them); the rest is counted.
        errors = 0;
        for (let i = 0; i < diagnostics.length; i++) {
          if (!ObjectHasOwn(diagnostics, i)) throw sparse('diagnostics');
          if (isError(diagnostics[i])) errors++;
        }
        if (hasNamedKeys(diagnostics)) st.stripped = true;
        total = diagnostics.length;
        source = keepErrorsFirst(diagnostics);
      }
      value.diagnostics = copyList(source, 'diagnostics', copyDiagnostic, st);
    }
    return { value, stripped: st.stripped, total, errors };
  } catch (error) {
    if (!(error instanceof Refusal)) throw error;
    if (error.kind === 'cyclic') return { cyclic: true };
    if (error.kind === 'oversize') return { oversize: st.chars };
    return { refusal: { path: error.path, message: error.message } };
  }
}

// ---- the host's second line: strip its own copy of a worker message ----

/** Deletes the keys of `target` outside `fields`; true when it deleted one. A key that cannot be deleted (a frozen object) is left. */
function strip(target, fields) {
  if (typeof target !== 'object' || target === null) return false;
  let stripped = false;
  const keys = ObjectKeys(target);
  for (let i = 0; i < keys.length; i++) {
    if (fields.has[keys[i]] === true) continue;
    try {
      stripped = delete target[keys[i]] || stripped;
    } catch {
      // not deletable: left as it is
    }
  }
  return stripped;
}

/** Deletes the keys of a list that are not indexes (a match array's `input`, for one); lists over 4096 items are left. */
function stripList(list) {
  if (!ArrayIsArray(list) || !hasNamedKeys(list)) return false;
  let stripped = false;
  const keys = ObjectKeys(list);
  for (let i = 0; i < keys.length; i++) {
    if (INDEX_KEY.test(keys[i])) continue;
    try {
      stripped = delete list[keys[i]] || stripped;
    } catch {
      // not deletable: left as it is
    }
  }
  return stripped;
}

/**
 * Removes, in place, every key outside the result contract from a result, its outputs (by kind), its
 * diagnostics and the nodes of its trees, and the named keys of every list in them, and says whether it
 * removed any. Index loops and a stack, no recursion. The worker posts a snapshot that has none (see
 * `snapshotResult`); the host runs this on its own copy of the message [GAP-654].
 */
export function stripUnknownKeys(result) {
  let stripped = strip(result, RESULT_SPEC);
  if (typeof result !== 'object' || result === null) return stripped;
  const diagnostics = result.diagnostics;
  stripped = stripList(diagnostics) || stripped;
  if (ArrayIsArray(diagnostics))
    for (let i = 0; i < diagnostics.length; i++)
      stripped = strip(diagnostics[i], DIAGNOSTIC_SPEC) || stripped;
  const outputs = result.outputs;
  stripped = stripList(outputs) || stripped;
  if (!ArrayIsArray(outputs)) return stripped;
  for (let i = 0; i < outputs.length; i++) {
    const output = outputs[i];
    if (typeof output !== 'object' || output === null) continue;
    stripped = strip(output, outputSpec(output.kind)) || stripped;
    if (output.kind === 'table') {
      stripped = stripList(output.columns) || stripped;
      stripped = stripList(output.rows) || stripped;
      if (ArrayIsArray(output.rows))
        for (let r = 0; r < output.rows.length; r++)
          stripped = stripList(output.rows[r]) || stripped;
    }
    if (output.kind !== 'tree') continue;
    const stack = [output.root];
    while (stack.length > 0) {
      const node = stack.pop();
      if (typeof node !== 'object' || node === null) continue;
      stripped = strip(node, NODE_SPEC) || stripped;
      const children = node.children;
      if (!ArrayIsArray(children)) continue;
      stripped = stripList(children) || stripped;
      for (let c = 0; c < children.length; c++) stack.push(children[c]);
    }
  }
  return stripped;
}
