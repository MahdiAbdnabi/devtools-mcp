import { installNetGuard } from './net-guard.mjs';
import { parentPort, workerData } from 'node:worker_threads';
import { describePlugin, runToolFromModule } from './execute.mjs';

// The guard is installed before the plugin module is imported, so plugin code only sees guarded modules.
installNetGuard({ nestedWorkers: true });

const errorText = (error) => {
  try {
    return error instanceof Error ? error.message : String(error);
  } catch {
    return 'unprintable value';
  }
};

// Bound before any plugin code is imported, so a plugin cannot intercept it.
const post = parentPort.postMessage.bind(parentPort);
// The host sends the per-call nonce first; plugin code is imported only after it.
const nonce = await new Promise((resolve) => {
  parentPort.once('message', (message) => resolve(message.nonce));
});

function send(message) {
  try {
    post({ nonce, ...message });
  } catch (error) {
    const describing = workerData.op === 'describe';
    post({
      nonce,
      type: 'failure',
      diagnostic: {
        severity: 'error',
        code: describing
          ? 'E_DESCRIBE_NOT_CLONEABLE'
          : 'E_RESULT_NOT_CLONEABLE',
        message: describing
          ? `plugin descriptors cannot be sent to the host: ${errorText(error)}`
          : `tool result cannot be sent to the host: ${errorText(error)}`,
      },
    });
  }
}

let mod;
try {
  mod = await import(workerData.entryUrl);
} catch (error) {
  send({
    type: 'failure',
    diagnostic: {
      severity: 'error',
      code: 'E_PLUGIN_LOAD',
      message: `plugin entry failed to load: ${errorText(error)}`,
    },
  });
}
if (mod !== undefined) {
  if (workerData.op === 'describe')
    send({
      type: 'describe',
      ...describePlugin(mod, workerData.withDocs === true),
    });
  else
    // The nonce also marks the worker's own drop notice; the plugin never sees this copy of the request (GAP-560).
    send({
      type: 'result',
      result: await runToolFromModule(mod, {
        ...workerData,
        noticeMark: nonce,
      }),
    });
}
