@echo off
setlocal
set NoDefaultCurrentDirectoryInExePath=1
where $PATH:node >nul 2>nul
if errorlevel 1 (
  echo The DevTools command line needs Node.js ^^22.18.0 ^|^| ^>=24.11.0 on your PATH. Install Node.js, open a new terminal and try again. 1>&2
  exit /b 127
)
node "%~dp0devtools.mjs" %*
exit /b %ERRORLEVEL%
