DevTools command line and MCP server, version 0.1.0

devtools-cli runs the DevTools tools from a terminal and serves them to AI clients
over the Model Context Protocol (devtools mcp). Everything runs on this computer;
nothing is sent over the network.

It needs Node.js ^22.18.0 || >=24.11.0 on the PATH.

Run a tool, from a Command Prompt (cmd.exe) in this folder:
  devtools list
  devtools json-xml.format-json --text "{\"a\":1}"

Add the MCP server to Claude Code (replace the folder with where this folder is):
  claude mcp add devtools --scope user -- node C:\path\to\devtools-cli\devtools.mjs mcp

For Claude Desktop and other clients, the options and troubleshooting, see the
MCP guide (MCP.md) that comes with the DevTools documentation.

Licence: MIT (LICENSE). Third-party code bundled here: THIRD-PARTY-NOTICES.txt.
